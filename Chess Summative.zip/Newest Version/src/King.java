/*
 * Programmers: George Fan, Joanna He, Maia Dinsdale, Liya Chu and Sasha Difelice Hanson
 * Course code: ICS4UE-20
 * Date: August 24, 2021
 * Assignment U4A3 - Implementation
 * Description: This program dictates the king's movements and accounts for castling
*/
// Importing library for ImageIcon
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class King extends Piece {
    
    // Constructor
    public King (int x, int y, boolean isWhite, ImageIcon image) {
        
        // Calls parent constructor, passes in variables
        super(x, y, isWhite, image);
    }
    
    @Override
    public boolean isLegalMove(Chess chess, int xPos, int yPos) {
        // If the target position is not a legal move then return false

        ArrayList<Piece> allPlayer = new ArrayList<Piece>();
        allPlayer.addAll(chess.whitePlayer);
        allPlayer.addAll(chess.blackPlayer);
        
        // Check if king has already moved
        if (!this.getHasMoved()) {
            // Checks if user attempts to move king two tiles right (castle kingside)
            if ((this.getX() + 2 == xPos) && (this.getY() == yPos)) {

                // Loops through two squares the king has to pass through
                for (int i = 1; i <= 2; i++) {
                    // Checks if the king would be in check
                    if (chess.inCheck(chess.turnCount%2, this.getX()+i, this.getY())) {
                        // Declares castling as illegal
                        return false;
                    } 

                    // Loops through all pieces
                    for (Piece z : allPlayer) {
                        // Checks if a piece occupies any of the two squares the king has to pass through
                        if (z.getX() == this.getX()+i && z.getY() == this.getY()) {
                            // Declares castling as illegal
                            return false;
                        }
                    }
                }

                // Loops through all pieces
                for (Piece z : allPlayer) {
                    // Checks if the piece is a rook on the H file, and if it's white's turn, that the rook is white and on the 1st rank, or if it's black's turn, that the rook is black and on the 8th rank
                    if ((z.getX() == 8 && z.getClass() == Rook.class) && ((chess.turnCount%2 == 0 && z.getIsWhite() && z.getY() == 1) || (chess.turnCount%2 == 1 && !z.getIsWhite() && z.getY() == 8))) {
                        // Checks if the rook has moved yet
                        if (!z.getHasMoved()) {
                            // Move the rook
                            z.setX(6);
                        } else {
                            // Declares castling as illegal
                            return false;
                        }
                    }
                }

                // Set has moved to true
                this.setHasMoved(true);
                return true; // Move the king into position
                
            // Checks if user attempts to move king two tiles left (castle queenside)  
            } else if ((this.getX() - 2 == xPos) && (this.getY() == yPos)) {
                
                // Loops through two squares the king has to pass through
                for (int i = 1; i <= 2; i++) {
                    // Checks if the king would be in check
                    if (chess.inCheck(chess.turnCount%2, this.getX()-i, this.getY())) {
                        // Declares castling as illegal
                        return false;
                    } 

                    // Loops through all pieces
                    for (Piece z : allPlayer) {
                        // Checks if a piece occupies any of the two squares the king has to pass through
                        if (z.getX() == this.getX()-i && z.getY() == this.getY()) {
                            // Declares castling as illegal
                            return false;
                        }
                    }
                }
                
                // Loops through all pieces
                for (Piece z : allPlayer) {
                    // Checks if the piece is a rook on the A file, and if it's white's turn, that the rook is white and on the 1st rank, or if it's black's turn, that the rook is black and on the 8th rank
                    if ((z.getX() == 1 && z.getClass() == Rook.class) && ((chess.turnCount%2 == 0 && z.getIsWhite() && z.getY() == 1) || (chess.turnCount%2 == 1 && !z.getIsWhite() && z.getY() == 8))) {
                        // Checks if the rook has moved yet
                        if (!z.getHasMoved()) {
                            // Move the rook
                            z.setX(4);
                        } else {
                            // Declares castling as illegal
                            return false;
                        }
                    }
                }
                
                // Set has moved to true
                this.setHasMoved(true);
                return true; // Move the king into position
            }
        }
        
        // Set a 2 dimesional array for all possible king moves
        int[][] legalKingMoves = new int[][] {{-1, 1}, {-1, 0}, {-1, -1}, {0, 1}, {0, -1}, {1, 1}, {1, 0}, {1, -1}};
        
        //iterate throught the legalKingMoves array to check if the desired move is legal
        for (int[] w : legalKingMoves) {
            if ((this.getX() + w[0] == xPos) && (this.getY() + w[1] == yPos)) {
                
                // Loops through the white pieces
                for (Piece z : chess.whitePlayer){
                
                    // If the target position has another piece of the same colour on it, return false
                    if ((z.getX() == xPos && z.getY() == yPos) && this.getIsWhite()) {
                        return false;
                    }
                }
            
                // Loops through the black pieces
                for (Piece z : chess.blackPlayer){
                
                    // If the target position has another piece of the same colour on it, return false
                    if ((z.getX() == xPos && z.getY() == yPos) && !this.getIsWhite()) {
                        return false;
                    }
                }
                
                // Set hasMoved to true
                this.setHasMoved(true);
                return true;
            }
        }
        // Return false
        return false;
    }
}
