/*
 * Programmers: George Fan, Joanna He, Maia Dinsdale, Liya Chu and Sasha Difelice Hanson
 * Course code: ICS4UE-20
 * Date: August 24, 2021
 * Assignment U4A3 - Implementation
 * Description: This program is the base piece, actual chess pieces inherit from this class, stores position, image, colour, and if it has moved or not
*/

// Importing library for ImageIcon
import javax.swing.ImageIcon;

public abstract class Piece {
    
    private int x, y; // Piece x and y position
    private boolean isWhite; // Piece colour
    private ImageIcon image; // Image to represent the piece
    private boolean hasMoved = false; // Tracks if a piece has been moved
    
    // Constructor
    public Piece(int x, int y, boolean isWhite, ImageIcon image) {
        // Sets global variables to variables passed in
        this.x = x;
        this.y = y;
        this.isWhite = isWhite;
        this.image = image;
    }
    
    // Returns whether the piece is black or white
    public boolean getIsWhite() {
        return isWhite;
    }
    
    // Returns the x position
    public int getX() {
        return x;
    }
    
    // Returns the y position
    public int getY() {
        return y;
    }
    
    // Sets the x position
    public void setX(int x) {
        this.x = x;
    }

    // Sets the y position
    public void setY(int y) {
        this.y = y;
    }
    
    // Returns the image icon
    public ImageIcon getImage() {
        return image;
    }
    
    // This method check if a move is legal, it will be overridden in the subclasses
    public boolean isLegalMove(Chess chess, int xPos, int yPos) {        
        return true;
    }
    
    // Returns the hasMoved variable
    public boolean getHasMoved() {
        return hasMoved;
    }
    
    // Sets the hasMoved variable
    public void setHasMoved(boolean x) {
        hasMoved = x;
    }
}